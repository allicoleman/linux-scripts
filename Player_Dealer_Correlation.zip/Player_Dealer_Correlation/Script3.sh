awk '{print $1, $2, $5, $6}' 031* | grep "08:00:00" | grep "PM"

